let id = [2322, 5091, 1017, 7804]
let name = ["John Smith", "Jane Mitchell", "Kate Stuart", "Pat Johnson"]
let department = ["Design", "Accounting", "Sales", "Manufacturing"]
let salary = [85250, 72968, 68225, 79000]
module.exports = {
    id,
    name,
    department,
    salary
}
